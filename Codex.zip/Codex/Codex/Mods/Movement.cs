﻿using GorillaLocomotion;
using Codex.Classes;
using UnityEngine;
using UnityEngine.XR;
using static Codex.Menu.Main;
using StupidTemplate.Classes;
using player = GorillaLocomotion.GTPlayer;

namespace Codex.Mods
{
    public class Movement
    {
        public static GameObject PlatR,PlatL;
        public static bool previousTeleportTrigger;
        public static void Fly()
        {
            if (Get.a)
            {
                player.Instance.transform.position += GorillaTagger.Instance.headCollider.transform.forward * Time.deltaTime * Settings.Movement.flySpeed;
                GorillaTagger.Instance.rigidbody.linearVelocity = Vector3.zero;
            }
        }
        public static void UpAndDown()
        {
            if (Get.rt)
            {
                player.Instance.transform.position += Vector3.up * Time.deltaTime * Settings.Movement.flySpeed;
                GorillaTagger.Instance.rigidbody.angularVelocity = Vector3.zero;
            }
            if (Get.lt)
            {
                player.Instance.transform.position += Vector3.down * Time.deltaTime * Settings.Movement.flySpeed;
                GorillaTagger.Instance.rigidbody.angularVelocity = Vector3.zero;
            }
        }
        public static void Platforms()
        {
            if (Get.rg)
            {
                if (PlatR == null)
                {
                    PlatR = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    PlatR.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);
                    PlatR.transform.rotation = GorillaTagger.Instance.rightHandTransform.rotation;
                    PlatR.transform.position = GorillaTagger.Instance.rightHandTransform.position;

                    PlatR.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                    PlatR.GetComponent<Renderer>().material.color = Color.gray1;
                }
            }
            else
            {
                if (PlatR != null)
                {
                    GameObject.Destroy(PlatR);
                    PlatR = null;
                }
            }

            if (Get.lg)
            {
                if (PlatL == null)
                {
                    PlatL = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    PlatL.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);
                    PlatL.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation;
                    PlatL.transform.position = GorillaTagger.Instance.leftHandTransform.position;

                    PlatR.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                    PlatR.GetComponent<Renderer>().material.color = Color.gray1;
                }
            }
            else
            {
                if (PlatL != null)
                {
                    GameObject.Destroy(PlatL);
                    PlatL = null;
                }
            }
        }
        public static void TeleportGun()
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                var GunData = Gunlib.RenderGun();
                GameObject NewPointer = GunData.NewPointer;

                if (ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.5f && !previousTeleportTrigger)
                {
                    player.Instance.TeleportTo(NewPointer.transform.position + Vector3.up, GTPlayer.Instance.transform.rotation);
                    GorillaTagger.Instance.rigidbody.linearVelocity = Vector3.zero;
                }

                previousTeleportTrigger = ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.5f;
            }
        }
    }
}
