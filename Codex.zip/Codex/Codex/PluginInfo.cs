namespace Codex
{
    public class PluginInfo
    {
        public const string GUID = "Codex.Menu";
        public const string Name = "Codex.";
        public const string Description = "BY Shortt & razx";
        public const string Version = "1.0";
    }
}
