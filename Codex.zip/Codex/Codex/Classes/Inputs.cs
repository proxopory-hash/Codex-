﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace StupidTemplate.Classes
{
    public class Get
    {
        public static bool rg => ControllerInputPoller.instance.rightGrab; 
        public static bool lg => ControllerInputPoller.instance.leftGrab; 
        public static bool y => ControllerInputPoller.instance.leftControllerSecondaryButton; 
        public static bool a => ControllerInputPoller.instance.leftControllerPrimaryButton; 
        public static bool b => ControllerInputPoller.instance.rightControllerSecondaryButton; 
        public static bool x => ControllerInputPoller.instance.rightControllerPrimaryButton; 
        public static bool rt => ControllerInputPoller.instance.rightControllerTriggerButton; 
        public static bool lt => ControllerInputPoller.instance.leftControllerTriggerButton; 
        public static bool rgfloat => ControllerInputPoller.instance.rightControllerGripFloat > 0.01; 
        public static bool lgfloat => ControllerInputPoller.instance.leftControllerGripFloat > 0.01; 
    }
}
