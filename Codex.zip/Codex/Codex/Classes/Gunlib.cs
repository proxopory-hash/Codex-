﻿using System;
using GorillaLocomotion;
using UnityEngine;
using UnityEngine.XR;

namespace Codex.Classes
{
    internal class Gunlib : MonoBehaviour
    {
        public static Color LineColor = Color.gray1;
        public static Color LineTriggerColor = Color.gray1;
        public static Color PointerColor = Color.gray1;
        public static Color PointerTriggerColor = Color.green;

        public static bool gunLocked;
        public static VRRig lockTarget;

        private static GameObject GunPointer;
        private static LineRenderer GunLine;
        private static int? noInvisLayerMask;
        private static Shader cachedShader;
        private static Shader TextShader => cachedShader ??= Shader.Find("GUI/Text Shader");

        /// <summary>
        /// Super simple wrapper: handles grab, pointing, raycasting, and executes your custom logic when trigger is pulled.
        /// </summary>
        /// <param name="onTriggerPressed">Action executed every frame the trigger is held down.</param>
        /// <param name="requireGrab">Whether the right grip button must be held to use the gun.</param>
        public static void RunGun(Action<RaycastHit, VRRig> onTriggerPressed, bool requireGrab = true)
        {
            bool isGrabbed = !requireGrab || ControllerInputPoller.instance.rightGrab;

            if (!isGrabbed)
            {
                CleanUpGun();
                return;
            }

            var (hit, pointer) = RenderGun();
            VRRig targetRig = hit.collider ? hit.collider.GetComponentInParent<VRRig>() : null;

            // Handle lock-on toggle (Press primary button / A button to lock target)
            if (ControllerInputPoller.instance.rightControllerPrimaryButton)
            {
                if (targetRig != null && lockTarget != targetRig)
                {
                    lockTarget = targetRig;
                    gunLocked = true;
                }
            }
            else if (ControllerInputPoller.instance.rightControllerSecondaryButton)
            {
                // Press secondary button to unlock
                lockTarget = null;
                gunLocked = false;
            }

            // Check trigger pull
            if (ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.5f)
            {
                VRRig activeTarget = gunLocked ? lockTarget : targetRig;
                onTriggerPressed?.Invoke(hit, activeTarget);
            }
        }

        public static void CleanUpGun()
        {
            try
            {
                if (GunPointer != null) { Destroy(GunPointer); GunPointer = null; }
                if (GunLine != null) { Destroy(GunLine.gameObject); GunLine = null; }
                gunLocked = false;
                lockTarget = null;
            }
            catch { }
        }

        public static (RaycastHit Ray, GameObject NewPointer) RenderGun(int? overrideLayerMask = null)
        {
            Transform gunTransform = GorillaTagger.Instance.rightHandTransform;
            Vector3 startPos = gunTransform.position;
            Vector3 direction = gunTransform.forward;

            Physics.Raycast(startPos + direction / 4f, direction, out var hit, 512f, overrideLayerMask ?? NoInvisLayerMask());
            Vector3 endPos = (gunLocked && lockTarget != null) ? lockTarget.transform.position : hit.point;

            if (endPos == Vector3.zero)
                endPos = startPos + direction * 512f;

            if (GunPointer == null)
            {
                GunPointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                Destroy(GunPointer.GetComponent<Collider>());
            }

            GunPointer.SetActive(true);
            GunPointer.transform.localScale = new Vector3(0.15f, 0.15f, 0.15f);
            GunPointer.transform.position = endPos;

            Renderer pointerRenderer = GunPointer.GetComponent<Renderer>();
            if (pointerRenderer != null)
            {
                pointerRenderer.material.shader = TextShader;
                pointerRenderer.material.color = (gunLocked || ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.5f) ? PointerTriggerColor : PointerColor;
            }

            if (GunLine == null)
            {
                GameObject lineObj = new GameObject("razx_line");
                GunLine = lineObj.AddComponent<LineRenderer>();
                GunLine.material.shader = TextShader;
                GunLine.startWidth = 0.020f;
                GunLine.endWidth = 0.020f;
                GunLine.positionCount = 2;
                GunLine.useWorldSpace = true;
            }

            GunLine.gameObject.SetActive(true);
            GunLine.startColor = LineColor;
            GunLine.endColor = LineTriggerColor;
            GunLine.SetPosition(0, startPos);
            GunLine.SetPosition(1, endPos);

            return (hit, GunPointer);
        }

        public static int NoInvisLayerMask()
        {
            if (noInvisLayerMask == null)
            {
                noInvisLayerMask = ~(
                    1 << LayerMask.NameToLayer("TransparentFX") |
                    1 << LayerMask.NameToLayer("Ignore Raycast") |
                    1 << LayerMask.NameToLayer("Zone") |
                    1 << LayerMask.NameToLayer("Gorilla Trigger") |
                    1 << LayerMask.NameToLayer("Gorilla Boundary") |
                    1 << LayerMask.NameToLayer("GorillaCosmetics") |
                    1 << LayerMask.NameToLayer("GorillaParticle"));
            }
            return noInvisLayerMask.Value;
        }
    }
}