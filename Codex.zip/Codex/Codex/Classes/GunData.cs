﻿using BepInEx;
using Codex.Menu;
using System;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR;

namespace Codex.Classes
{
    public class GunData : MonoBehaviour
    {
        public static GameObject Pointer;
        public static VRRig LockedPlayer;
        public static RaycastHit nray;

        // Customization Settings
        public static float PointerScale = 0.2f;
        public static float LineWidth = 0.025f;
        public static float Smoothness = 15f; // Used only when LineType.Smooth is active

        // Left-hand toggle property
        public static bool isLeftHanded = false;

        // Line Customization
        public enum LineType
        {
            Solid,
            Dotted,
            Dashed,
            Gradient,
            Pulse,
            Wavey,
            Spiral,
            Smooth,
            PointerOnly
        }

        public static LineType currentLineType = LineType.Solid;
        public static Texture2D dottedTexture;
        public static Texture2D dashedTexture;

        private static LineRenderer gunLine;
        private static int? noInvisLayerMask;

        // Interpolation tracking variables for Smooth mode
        private static Vector3 currentPointerPos;
        private static Vector3 currentLineStartPos;

        public static int NoInvisLayerMask()
        {
            noInvisLayerMask ??= ~(
                1 << LayerMask.NameToLayer("TransparentFX") |
                1 << LayerMask.NameToLayer("Ignore Raycast") |
                1 << LayerMask.NameToLayer("Zone") |
                1 << LayerMask.NameToLayer("Gorilla Trigger") |
                1 << LayerMask.NameToLayer("Gorilla Boundary") |
                1 << LayerMask.NameToLayer("GorillaCosmetics") |
                1 << LayerMask.NameToLayer("GorillaParticle"));

            return noInvisLayerMask.Value;
        }

        public static void StartVrGun(Action action, bool LockOn)
        {
            bool grabPressed = isLeftHanded
                ? ControllerInputPoller.instance.leftGrab
                : ControllerInputPoller.instance.rightGrab;

            if (grabPressed)
            {
                Transform handTransform = isLeftHanded
                    ? GorillaTagger.Instance.leftHandTransform
                    : GorillaTagger.Instance.rightHandTransform;

                Vector3 startPos = handTransform.position;
                Vector3 direction = handTransform.forward;

                Physics.Raycast(startPos + direction / 4f, direction, out nray, 512f, NoInvisLayerMask());

                if (Pointer == null)
                {
                    Pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    currentPointerPos = startPos;
                    currentLineStartPos = startPos;
                }

                Pointer.SetActive(true);
                Pointer.transform.localScale = new Vector3(PointerScale, PointerScale, PointerScale);
                Destroy(Pointer.GetComponent<Collider>());

                Renderer pointerRenderer = Pointer.GetComponent<Renderer>();
                pointerRenderer.material.shader = Shader.Find("GUI/Text Shader");

                bool triggerPressed = isLeftHanded
                    ? ControllerInputPoller.instance.leftControllerIndexFloat > 0.5f
                    : ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f;

                Vector3 targetPos;

                if (triggerPressed)
                {
                    if (LockOn && LockedPlayer == null && nray.collider != null)
                    {
                        VRRig detectedRig = nray.collider.GetComponentInParent<VRRig>();
                        if (detectedRig != null && detectedRig != GorillaTagger.Instance.offlineVRRig)
                        {
                            LockedPlayer = detectedRig;
                        }
                    }

                    if (LockOn)
                    {
                        if (LockedPlayer != null)
                        {
                            targetPos = LockedPlayer.transform.position;
                            pointerRenderer.material.color = Color.gray1;
                            action?.Invoke();
                        }
                        else
                        {
                            targetPos = nray.point == Vector3.zero ? startPos + direction * 512f : nray.point;
                            pointerRenderer.material.color = Color.gray1;
                        }
                    }
                    else
                    {
                        targetPos = nray.point == Vector3.zero ? startPos + direction * 512f : nray.point;
                        pointerRenderer.material.color = Color.gray1;
                        action?.Invoke();
                    }
                }
                else
                {
                    LockedPlayer = null;
                    targetPos = nray.point == Vector3.zero ? startPos + direction * 512f : nray.point;
                    pointerRenderer.material.color = Color.gray1;
                }

                // Smooth delay interpolation ONLY when on Smooth mode
                if (currentLineType == LineType.Smooth)
                {
                    currentPointerPos = Vector3.Lerp(currentPointerPos, targetPos, Time.deltaTime * Smoothness);
                    currentLineStartPos = Vector3.Lerp(currentLineStartPos, startPos, Time.deltaTime * Smoothness);
                }
                else
                {
                    currentPointerPos = targetPos;
                    currentLineStartPos = startPos;
                }

                Pointer.transform.position = currentPointerPos;
                DrawLine(currentLineStartPos, currentPointerPos);
            }
            else
            {
                Cleanup();
            }
        }

        public static void StartPcGun(Action action, bool LockOn)
        {
            if (Mouse.current.rightButton.isPressed)
            {
                Camera mainCam = GorillaTagger.Instance.mainCamera.GetComponent<Camera>();
                Vector2 mousePos = Mouse.current.position.ReadValue();

                Ray ray = mainCam.ScreenPointToRay(mousePos);
                Physics.Raycast(ray, out nray, 512f, NoInvisLayerMask());

                Vector3 startPos = mainCam.transform.position;

                if (Pointer == null)
                {
                    Pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    currentPointerPos = startPos;
                    currentLineStartPos = startPos;
                }

                Pointer.SetActive(true);
                Pointer.transform.localScale = new Vector3(PointerScale, PointerScale, PointerScale);
                Destroy(Pointer.GetComponent<Collider>());

                Renderer pointerRenderer = Pointer.GetComponent<Renderer>();
                pointerRenderer.material.shader = Shader.Find("GUI/Text Shader");

                bool leftClickPressed = Mouse.current.leftButton.isPressed;

                Vector3 targetPos;

                if (leftClickPressed)
                {
                    if (LockOn && LockedPlayer == null && nray.collider != null)
                    {
                        VRRig detectedRig = nray.collider.GetComponentInParent<VRRig>();
                        if (detectedRig != null && detectedRig != GorillaTagger.Instance.offlineVRRig)
                        {
                            LockedPlayer = detectedRig;
                        }
                    }

                    if (LockOn)
                    {
                        if (LockedPlayer != null)
                        {
                            targetPos = LockedPlayer.transform.position;
                            pointerRenderer.material.color = Color.gray1;
                            action?.Invoke();
                        }
                        else
                        {
                            targetPos = nray.point == Vector3.zero ? ray.origin + ray.direction * 512f : nray.point;
                            pointerRenderer.material.color = Color.gray1;
                        }
                    }
                    else
                    {
                        targetPos = nray.point == Vector3.zero ? ray.origin + ray.direction * 512f : nray.point;
                        pointerRenderer.material.color = Color.gray1;
                        action?.Invoke();
                    }
                }
                else
                {
                    LockedPlayer = null;
                    targetPos = nray.point == Vector3.zero ? ray.origin + ray.direction * 512f : nray.point;
                    pointerRenderer.material.color = Color.gray1;
                }

                // Smooth delay interpolation ONLY when on Smooth mode
                if (currentLineType == LineType.Smooth)
                {
                    currentPointerPos = Vector3.Lerp(currentPointerPos, targetPos, Time.deltaTime * Smoothness);
                    currentLineStartPos = Vector3.Lerp(currentLineStartPos, startPos, Time.deltaTime * Smoothness);
                }
                else
                {
                    currentPointerPos = targetPos;
                    currentLineStartPos = startPos;
                }

                Pointer.transform.position = currentPointerPos;
                DrawLine(currentLineStartPos, currentPointerPos);
            }
            else
            {
                Cleanup();
            }
        }

        public static void ExampleGun()
        {
            Start(delegate { }, false);
        }

        public static void ExampleGunLock()
        {
            Start(delegate { }, true);
        }

        public static void Start(Action action, bool LockOn = false)
        {
            if (XRSettings.isDeviceActive)
                StartVrGun(action, LockOn);
            else
                StartPcGun(action, LockOn);
        }

        private static void DrawLine(Vector3 start, Vector3 end)
        {
            if (currentLineType == LineType.PointerOnly)
            {
                if (gunLine != null) gunLine.gameObject.SetActive(false);
                return;
            }

            if (gunLine == null)
            {
                GameObject lineObj = new GameObject("razx_GunLine");
                gunLine = lineObj.AddComponent<LineRenderer>();
            }

            gunLine.gameObject.SetActive(true);
            gunLine.material.shader = Shader.Find("GUI/Text Shader");
            gunLine.useWorldSpace = true;

            Color themeColor = Color.gray1;

            switch (currentLineType)
            {
                case LineType.Solid:
                    gunLine.positionCount = 2;
                    gunLine.startWidth = LineWidth;
                    gunLine.endWidth = LineWidth;
                    gunLine.material.mainTexture = null;
                    gunLine.startColor = themeColor;
                    gunLine.endColor = themeColor;
                    gunLine.SetPosition(0, start);
                    gunLine.SetPosition(1, end);
                    break;

                case LineType.Dotted:
                    gunLine.positionCount = 2;
                    gunLine.startWidth = LineWidth;
                    gunLine.endWidth = LineWidth;
                    EnsurePatternTextures();
                    gunLine.material.mainTexture = dottedTexture;
                    gunLine.material.mainTextureScale = new Vector2(Vector3.Distance(start, end) * 4f, 1f);
                    gunLine.startColor = themeColor;
                    gunLine.endColor = themeColor;
                    gunLine.SetPosition(0, start);
                    gunLine.SetPosition(1, end);
                    break;

                case LineType.Dashed:
                    gunLine.positionCount = 2;
                    gunLine.startWidth = LineWidth;
                    gunLine.endWidth = LineWidth;
                    EnsurePatternTextures();
                    gunLine.material.mainTexture = dashedTexture;
                    gunLine.material.mainTextureScale = new Vector2(Vector3.Distance(start, end) * 2f, 1f);
                    gunLine.startColor = themeColor;
                    gunLine.endColor = themeColor;
                    gunLine.SetPosition(0, start);
                    gunLine.SetPosition(1, end);
                    break;

                case LineType.Gradient:
                    gunLine.positionCount = 2;
                    gunLine.startWidth = LineWidth;
                    gunLine.endWidth = LineWidth;
                    gunLine.material.mainTexture = null;
                    gunLine.startColor = themeColor;
                    gunLine.endColor = new Color(themeColor.r, themeColor.g, themeColor.b, 0.1f);
                    gunLine.SetPosition(0, start);
                    gunLine.SetPosition(1, end);
                    break;

                case LineType.Pulse:
                    gunLine.positionCount = 2;
                    gunLine.material.mainTexture = null;
                    float pulse = (Mathf.Sin(Time.time * 8f) + 1f) / 2f;
                    float pulseWidth = Mathf.Lerp(LineWidth * 0.6f, LineWidth * 1.6f, pulse);
                    gunLine.startWidth = pulseWidth;
                    gunLine.endWidth = pulseWidth;

                    Color pulseColor = Color.Lerp(themeColor * 0.4f, themeColor, pulse);
                    pulseColor.a = themeColor.a;
                    gunLine.startColor = pulseColor;
                    gunLine.endColor = pulseColor;
                    gunLine.SetPosition(0, start);
                    gunLine.SetPosition(1, end);
                    break;

                case LineType.Wavey:
                    gunLine.material.mainTexture = null;
                    gunLine.startWidth = LineWidth;
                    gunLine.endWidth = LineWidth;
                    gunLine.startColor = themeColor;
                    gunLine.endColor = themeColor;

                    int waveSegments = 30;
                    gunLine.positionCount = waveSegments;
                    Vector3 waveDir = (end - start).normalized;
                    Vector3 waveUp = Vector3.Cross(waveDir, Vector3.up).normalized;
                    if (waveUp == Vector3.zero) waveUp = Vector3.right;

                    for (int i = 0; i < waveSegments; i++)
                    {
                        float t = i / (float)(waveSegments - 1);
                        Vector3 pointOnLine = Vector3.Lerp(start, end, t);
                        float offset = Mathf.Sin(t * 20f + Time.time * 10f) * 0.1f;
                        gunLine.SetPosition(i, pointOnLine + waveUp * offset);
                    }
                    break;

                case LineType.Spiral:
                    gunLine.material.mainTexture = null;
                    gunLine.startWidth = LineWidth;
                    gunLine.endWidth = LineWidth;
                    gunLine.startColor = themeColor;
                    gunLine.endColor = themeColor;

                    int spiralSegments = 50;
                    gunLine.positionCount = spiralSegments;
                    Vector3 forward = (end - start).normalized;
                    Vector3 right = Vector3.Cross(forward, Vector3.up).normalized;
                    if (right == Vector3.zero) right = Vector3.right;
                    Vector3 up = Vector3.Cross(right, forward).normalized;

                    for (int i = 0; i < spiralSegments; i++)
                    {
                        float t = i / (float)(spiralSegments - 1);
                        Vector3 pointOnLine = Vector3.Lerp(start, end, t);
                        float angle = t * 30f + Time.time * 8f;
                        float radius = 0.08f;
                        Vector3 spiralOffset = (right * Mathf.Cos(angle) + up * Mathf.Sin(angle)) * radius;
                        gunLine.SetPosition(i, pointOnLine + spiralOffset);
                    }
                    break;

                case LineType.Smooth:
                    gunLine.material.mainTexture = null;
                    gunLine.startWidth = LineWidth * 1.6f;
                    gunLine.endWidth = LineWidth * 0.2f;
                    gunLine.startColor = themeColor;
                    gunLine.endColor = new Color(themeColor.r, themeColor.g, themeColor.b, 0.3f);
                    gunLine.positionCount = 2;
                    gunLine.SetPosition(0, start);
                    gunLine.SetPosition(1, end);
                    break;
            }
        }

        private static void EnsurePatternTextures()
        {
            if (dottedTexture == null)
            {
                dottedTexture = new Texture2D(2, 1, TextureFormat.RGBA32, false);
                dottedTexture.SetPixel(0, 0, Color.white);
                dottedTexture.SetPixel(1, 0, Color.clear);
                dottedTexture.wrapMode = TextureWrapMode.Repeat;
                dottedTexture.filterMode = FilterMode.Point;
                dottedTexture.Apply();
            }

            if (dashedTexture == null)
            {
                dashedTexture = new Texture2D(4, 1, TextureFormat.RGBA32, false);
                dashedTexture.SetPixel(0, 0, Color.white);
                dashedTexture.SetPixel(1, 0, Color.white);
                dashedTexture.SetPixel(2, 0, Color.clear);
                dashedTexture.SetPixel(3, 0, Color.clear);
                dashedTexture.wrapMode = TextureWrapMode.Repeat;
                dashedTexture.filterMode = FilterMode.Point;
                dashedTexture.Apply();
            }
        }

        public static void Cleanup()
        {
            if (Pointer != null)
            {
                Destroy(Pointer);
                Pointer = null;
            }

            if (gunLine != null)
            {
                Destroy(gunLine.gameObject);
                gunLine = null;
            }

            LockedPlayer = null;
        }
    }
}